<img src="<?php echo e(asset('images/logo.png')); ?>" <?php echo e($attributes); ?> alt="Logo" />
<?php /**PATH C:\xampp\htdocs\1\resources\views/components/application-logo.blade.php ENDPATH**/ ?>